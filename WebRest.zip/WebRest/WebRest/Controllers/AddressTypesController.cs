using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRestEF.EF.Data;
using WebRestEF.EF.Models;

namespace WebRest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressTypesController : ControllerBase, iController<AddressType>
    {
        private readonly WebRestOracleContext _context;

        public AddressTypesController(WebRestOracleContext context)
        {
            _context = context;
        }

        // GET: api/AddressTypeTypes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AddressType>>> Get()
        {
            return await _context.AddressTypes.ToListAsync();
        }

        // GET: api/AddressTypes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AddressType>> Get(string id)
        {
            var addresstype = await _context.AddressTypes.FindAsync(id);

            if (addresstype == null)
            {
                return NotFound();
            }

            return addresstype;
        }

        // PUT: api/AddressTypes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, AddressType addresstype)
        {
            if (id != addresstype.AddressTypeId)
            {
                return BadRequest();
            }

            //_context.Entry(address).State = EntityState.Modified;
            var _item = _context.AddressTypes.FirstOrDefault(x => x.AddressTypeId == id);
            if (_item != null)
            {
                _item.AddressTypeDesc = addresstype.AddressTypeDesc;
                _context.AddressTypes.Update(_item);
                await _context.SaveChangesAsync();
            }



            return Ok();
        }

        // POST: api/AddressTypes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AddressType>> Post(AddressType addresstype)
        {
            _context.AddressTypes.Add(addresstype);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAddressType", new { id = addresstype.AddressTypeId }, addresstype);
        }

        // DELETE: api/AddressTypes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var addresstype = await _context.AddressTypes.FindAsync(id);
            if (addresstype == null)
            {
                return NotFound();
            }

            _context.AddressTypes.Remove(addresstype);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AddressExists(string id)
        {
            return _context.AddressTypes.Any(e => e.AddressTypeId == id);
        }
    }
}
