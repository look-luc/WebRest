using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRestEF.EF.Data;
using WebRestEF.EF.Models;

namespace WebRest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderStatesController : ControllerBase, iController<OrderState>
    {
        private readonly WebRestOracleContext _context;

        public OrderStatesController(WebRestOracleContext context)
        {
            _context = context;
        }

        // GET: api/CustomerOrderStates
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderState>>> Get()
        {
            return await _context.OrderStates.ToListAsync();
        }

        // GET: api/OrderStates/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderState>> Get(string id)
        {
            var orderstate = await _context.OrderStates.FindAsync(id);

            if (orderstate == null)
            {
                return NotFound();
            }

            return orderstate;
        }

        // PUT: api/OrderStates/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, OrderState orderstate)
        {
            if (id != orderstate.OrderStateId)
            {
                return BadRequest();
            }

            //_context.Entry(address).State = EntityState.Modified;
            var _item = _context.OrderStates.FirstOrDefault(x => x.OrderStateId == id);
            if (_item != null)
            {
                _item.OrderStateOrdersId = orderstate.OrderStateOrdersId;
                _context.OrderStates.Update(_item);
                await _context.SaveChangesAsync();
            }



            return Ok();
        }

        // POST: api/OrderStates
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<OrderState>> Post(OrderState orderstate)
        {
            _context.OrderStates.Add(orderstate);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrderState", new { id = orderstate.OrderStateId }, orderstate);
        }

        // DELETE: api/OrderStates/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var orderstate = await _context.OrderStates.FindAsync(id);
            if (orderstate == null)
            {
                return NotFound();
            }

            _context.OrderStates.Remove(orderstate);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AddressExists(string id)
        {
            return _context.OrderStates.Any(e => e.OrderStateId == id);
        }
    }
}
