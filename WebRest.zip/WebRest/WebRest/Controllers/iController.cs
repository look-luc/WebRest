using System;
using Microsoft.AspNetCore.Mvc;

namespace WebRest.Controllers{
    public interface iController<T>{
        Task<ActionResult<IEnumerable<T>>> Get();
        Task<ActionResult<T>> Get(string id);
        Task<IActionResult> Put(string id, T _tiem);
        Task<ActionResult<T>> Post(T _tiem);
        Task<IActionResult> Delete(string id);
    }
}