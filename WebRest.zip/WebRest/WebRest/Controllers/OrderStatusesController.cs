using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRestEF.EF.Data;
using WebRestEF.EF.Models;

namespace WebRest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderStatusesController : ControllerBase, iController<OrderStatus>
    {
        private readonly WebRestOracleContext _context;

        public OrderStatusesController(WebRestOracleContext context)
        {
            _context = context;
        }

        // GET: api/OrderStatuses
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderStatus>>> Get()
        {
            return await _context.OrderStatuses.ToListAsync();
        }

        // GET: api/OrderStatuses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderStatus>> Get(string id)
        {
            var orderstatus = await _context.OrderStatuses.FindAsync(id);

            if (orderstatus == null)
            {
                return NotFound();
            }

            return orderstatus;
        }

        // PUT: api/OrderStatuses/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, OrderStatus orderstatus)
        {
            if (id != orderstatus.OrderStatusId)
            {
                return BadRequest();
            }

            //_context.Entry(orderstatus).State = EntityState.Modified;
            var _item = _context.OrderStatuses.FirstOrDefault(x => x.OrderStatusId == id);
            if (_item != null)
            {
                _item.OrderStatusDesc = orderstatus.OrderStatusDesc;
                _context.OrderStatuses.Update(_item);
                await _context.SaveChangesAsync();
            }



            return Ok();
        }

        // POST: api/OrderStatuses
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<OrderStatus>> Post(OrderStatus orderstatus)
        {
            _context.OrderStatuses.Add(orderstatus);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetOrderStatus", new { id = orderstatus.OrderStatusId }, orderstatus);
        }

        // DELETE: api/OrderStatuses/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var orderstatus = await _context.OrderStatuses.FindAsync(id);
            if (orderstatus == null)
            {
                return NotFound();
            }

            _context.OrderStatuses.Remove(orderstatus);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrderStatusExists(string id)
        {
            return _context.OrderStatuses.Any(e => e.OrderStatusId == id);
        }
    }
}
