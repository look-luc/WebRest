using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRestEF.EF.Data;
using WebRestEF.EF.Models;

namespace WebRest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerAddressesController : ControllerBase, iController<CustomerAddress>
    {
        private readonly WebRestOracleContext _context;

        public CustomerAddressesController(WebRestOracleContext context)
        {
            _context = context;
        }

        // GET: api/CustomerCustomerAddresss
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CustomerAddress>>> Get()
        {
            return await _context.CustomerAddresses.ToListAsync();
        }

        // GET: api/CustomerAddresses/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CustomerAddress>> Get(string id)
        {
            var customeraddress = await _context.CustomerAddresses.FindAsync(id);

            if (customeraddress == null)
            {
                return NotFound();
            }

            return customeraddress;
        }

        // PUT: api/CustomerAddresses/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(string id, CustomerAddress customeraddress)
        {
            if (id != customeraddress.CustomerAddressId)
            {
                return BadRequest();
            }

            //_context.Entry(address).State = EntityState.Modified;
            var _item = _context.CustomerAddresses.FirstOrDefault(x => x.CustomerAddressId == id);
            if (_item != null)
            {
                _item.CustomerAddressCustomerId = customeraddress.CustomerAddressCustomerId;
                _context.CustomerAddresses.Update(_item);
                await _context.SaveChangesAsync();
            }



            return Ok();
        }

        // POST: api/CustomerAddresses
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CustomerAddress>> Post(CustomerAddress customeraddress)
        {
            _context.CustomerAddresses.Add(customeraddress);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCustomerAddress", new { id = customeraddress.CustomerAddressId }, customeraddress);
        }

        // DELETE: api/CustomerAddresses/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var customeraddress = await _context.CustomerAddresses.FindAsync(id);
            if (customeraddress == null)
            {
                return NotFound();
            }

            _context.CustomerAddresses.Remove(customeraddress);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AddressExists(string id)
        {
            return _context.CustomerAddresses.Any(e => e.CustomerAddressId == id);
        }
    }
}
